import heapq
import sys # Importar sys para ler do stdin

def dijkstra(graph, start_node):
    """
    Implementa o algoritmo de Dijkstra para encontrar o menor caminho
    de um nó inicial para todos os outros nós em um grafo.

    Args:
        graph (dict): O grafo representado como um dicionário.
                      Ex: { 'A': {'B': 50, 'C': 30}, ... }
        start_node (str): O nó inicial para o cálculo do menor caminho.

    Returns:
        tuple: Um tupla contendo dois dicionários:
               - distances (dict): Menor distância do nó inicial para cada nó.
               - predecessors (dict): Predecessor de cada nó no menor caminho.
    """
    distances = {node: float('infinity') for node in graph}
    distances[start_node] = 0
    predecessors = {node: None for node in graph}
    priority_queue = [(0, start_node)]  # (distance, node)

    while priority_queue:
        current_distance, current_node = heapq.heappop(priority_queue)

        # Se já encontramos um caminho mais curto, pulamos este.
        if current_distance > distances[current_node]:
            continue

        for neighbor, weight in graph[current_node].items():
            distance = current_distance + weight

            # Se encontramos um caminho mais curto para o vizinho
            if distance < distances[neighbor]:
                distances[neighbor] = distance
                predecessors[neighbor] = current_node
                heapq.heappush(priority_queue, (distance, neighbor))

    return distances, predecessors

def reconstruct_path(predecessors, start_node, end_node):
    """
    Reconstrói o caminho mais curto usando o dicionário de predecessores.

    Args:
        predecessors (dict): Dicionário de predecessores retornado por Dijkstra.
        start_node (str): O nó de início do caminho.
        end_node (str): O nó de destino do caminho.

    Returns:
        list: Uma lista de nós que representa o caminho mais curto.
              Retorna uma lista vazia se não houver caminho.
    """
    path = []
    current = end_node
    while current is not None:
        path.insert(0, current)
        current = predecessors[current]
        if current == start_node:
            path.insert(0, start_node)
            break
    if path and path[0] == start_node and path[-1] == end_node: # Adicionado 'path and' para evitar erro se path estiver vazio
        return path
    return []

def parse_input_from_stdin():
    """
    Lê a entrada para construir o grafo do stdin (teclado/pipe).

    Returns:
        dict: O grafo representado como um dicionário.
    """
    graph = {}
    current_node = None
    print("Por favor, insira os dados do grafo (Ctrl+D ou Ctrl+Z+Enter para finalizar):")
    for line in sys.stdin: # Lê linha por linha do stdin
        line = line.strip()
        if not line: # Ignora linhas em branco
            continue

        parts = line.split()
        if len(parts) == 1:
            current_node = parts[0]
            if current_node not in graph:
                graph[current_node] = {}
        elif len(parts) == 2:
            neighbor = parts[0]
            try:
                weight = float(parts[1])
            except ValueError:
                print(f"Aviso: Peso inválido '{parts[1]}' na linha: {line}. Ignorando.")
                continue

            if current_node and current_node in graph:
                graph[current_node][neighbor] = weight
            else:
                print(f"Aviso: Nó '{current_node}' não encontrado para adicionar aresta a '{neighbor}'. Verifique a ordem de entrada.")
        else:
            print(f"Aviso: Linha ignorada por formato inválido: {line}")
    return graph

def format_output(start_node, distances, predecessors, all_nodes):
    """
    Formata a saída para o problema.

    Args:
        start_node (str): O nó inicial de onde os caminhos foram calculados.
        distances (dict): Dicionário de distâncias.
        predecessors (dict): Dicionário de predecessores.
        all_nodes (list): Uma lista de todos os nós no grafo.
    """
    output_lines = []
    sorted_nodes = sorted(list(all_nodes)) # Garante uma ordem de saída consistente

    for target_node in sorted_nodes:
        if target_node == start_node:
            continue

        distance = distances.get(target_node, float('infinity')) # Use .get para evitar KeyError se nó não for alcançável
        path = reconstruct_path(predecessors, start_node, target_node)

        output_lines.append(f"{start_node} para {target_node}")
        if distance == float('infinity'):
            output_lines.append(f"Distancia: INFINITO")
            output_lines.append(f"Caminho: Não encontrado")
        else:
            output_lines.append(f"Distancia: {distance:.1f}")
            if path:
                path_str = " --> ".join(path[1:]) # Remove o nó inicial do "-->"
                output_lines.append(f"Caminho: --> {path_str}")
            else:
                output_lines.append("Caminho: Não encontrado (erro na reconstrução ou nó inalcançável)")
        output_lines.append("") # Linha em branco para separar as entradas
    return "\n".join(output_lines)

if __name__ == "__main__":
    # 1. Parsing da entrada para construir o grafo, agora do stdin
    graph_from_user = parse_input_from_stdin()

    # Verifica se o grafo foi construído
    if not graph_from_user:
        print("Nenhum dado de grafo foi inserido ou o formato está incorreto. Encerrando.")
        sys.exit(1) # Sai com código de erro

    # 2. Encontrar todos os nós únicos no grafo para iterar
    all_nodes_in_graph = list(graph_from_user.keys())

    # 3. Calcular e exibir os caminhos para cada nó inicial
    final_output = []
    for start_node_iter in sorted(all_nodes_in_graph): # Ordena para saída consistente
        distances, predecessors = dijkstra(graph_from_user, start_node_iter)
        final_output.append(format_output(start_node_iter, distances, predecessors, all_nodes_in_graph))
        final_output.append("-" * 45) # Separador entre os nós iniciais

    print("\n".join(final_output))