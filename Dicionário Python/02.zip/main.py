import heapq
import sys

def dijkstra(graph, start_node):
    """
    Implementa o algoritmo de Dijkstra para encontrar o menor caminho
    de um nó inicial para todos os outros nós em um grafo.

    Args:
        graph (dict): O grafo representado como um dicionário.
                      Ex: { 'A': {'B': 50, 'C': 30}, ... }
        start_node (str): O nó inicial para o cálculo do menor caminho.

    Returns:
        tuple: Um tupla contendo dois dicionários:
               - distances (dict): Menor distância do nó inicial para cada nó.
               - predecessors (dict): Predecessor de cada nó no menor caminho.
    """
    distances = {node: float('infinity') for node in graph}
    distances[start_node] = 0
    predecessors = {node: None for node in graph}
    priority_queue = [(0, start_node)]  # (distance, node)

    while priority_queue:
        current_distance, current_node = heapq.heappop(priority_queue)

        # Se já encontramos um caminho mais curto, pulamos este.
        if current_distance > distances[current_node]:
            continue

        for neighbor, weight in graph[current_node].items():
            distance = current_distance + weight

            # Se encontramos um caminho mais curto para o vizinho
            if distance < distances[neighbor]:
                distances[neighbor] = distance
                predecessors[neighbor] = current_node
                heapq.heappush(priority_queue, (distance, neighbor))

    return distances, predecessors

def reconstruct_path(predecessors, start_node, end_node):
    """
    Reconstrói o caminho mais curto usando o dicionário de predecessores.

    Args:
        predecessors (dict): Dicionário de predecessores retornado por Dijkstra.
        start_node (str): O nó de início do caminho.
        end_node (str): O nó de destino do caminho.

    Returns:
        list: Uma lista de nós que representa o caminho mais curto.
              Retorna uma lista vazia se não houver caminho.
    """
    path = []
    current = end_node
    while current is not None and current != start_node: # Adiciona o nó atual se não for o de início
        path.insert(0, current)
        current = predecessors[current]
    
    # Se o current se tornou None antes de chegar ao start_node, significa que não há caminho
    if current is None and end_node != start_node:
        return []

    # Adiciona o nó inicial no começo do caminho se ele é o predecessor ou se o caminho é apenas ele mesmo
    if current == start_node or (not path and start_node == end_node):
        path.insert(0, start_node)
    
    # Verifica se o caminho reconstruído é válido
    if path and path[0] == start_node and path[-1] == end_node:
        return path
    
    return [] # Retorna vazio se o caminho não pôde ser completamente reconstruído

def parse_input_from_stdin():
    """
    Lê a entrada para construir o grafo do stdin (teclado/pipe).

    Returns:
        dict: O grafo representado como um dicionário.
    """
    graph = {}
    current_node = None
    # Removendo a mensagem interativa aqui para que a saída de makesize seja limpa.
    # Se quiser a mensagem de volta para testes interativos, descomente abaixo:
    # print("Por favor, insira os dados do grafo (Ctrl+D ou Ctrl+Z+Enter para finalizar):")
    for line in sys.stdin:
        line = line.strip()
        if not line: # Ignora linhas em branco
            continue

        # Verifica se a linha contém apenas um nome (nó principal)
        # ou se contém um nome e um peso (vizinho)
        parts = line.split()
        if len(parts) == 1:
            current_node = parts[0]
            if current_node not in graph:
                graph[current_node] = {}
        elif len(parts) == 2:
            neighbor = parts[0]
            try:
                weight = float(parts[1])
            except ValueError:
                # print(f"Aviso: Peso inválido '{parts[1]}' na linha: {line}. Ignorando.")
                continue

            if current_node: # Garante que temos um nó principal definido
                if current_node not in graph: # Adiciona o nó principal se ainda não existe
                    graph[current_node] = {}
                graph[current_node][neighbor] = weight
            # else:
                # print(f"Aviso: Vizinho '{neighbor}' listado sem um nó principal definido. Linha: {line}")
        # else:
            # print(f"Aviso: Linha ignorada por formato inválido: {line}")
    return graph

def format_output(start_node, distances, predecessors, all_nodes):
    """
    Formata a saída para o problema.

    Args:
        start_node (str): O nó inicial de onde os caminhos foram calculados.
        distances (dict): Dicionário de distâncias.
        predecessors (dict): Dicionário de predecessores.
        all_nodes (list): Uma lista de todos os nós no grafo.
    """
    output_lines = []
    # Garante a ordem alfabética dos nós na saída, exceto pelo nó inicial.
    # Queremos os caminhos de 'start_node' para TODOS os outros, ordenados alfabeticamente.
    # Excluímos o próprio start_node para não gerar "A para A"
    sorted_target_nodes = sorted([node for node in all_nodes if node != start_node])

    for target_node in sorted_target_nodes:
        distance = distances.get(target_node, float('infinity'))
        path = reconstruct_path(predecessors, start_node, target_node)

        output_lines.append(f"{start_node} para {target_node}")
        if distance == float('infinity'):
            output_lines.append(f"\tDistancia: INFINITO")
            output_lines.append(f"\tCaminho: Não encontrado")
        else:
            output_lines.append(f"\tDistancia: {distance:.1f}")
            if path:
                # Remove o nó inicial para a formatação do caminho como "--> Nó2 --> Nó3"
                path_str_segments = path[1:]
                if path_str_segments: # Só adiciona "-->" se houver segmentos
                    path_str = " --> ".join(path_str_segments)
                    output_lines.append(f"\tCaminho:  --> {path_str}")
                else: # Caso o caminho seja apenas o nó inicial para ele mesmo (que já filtramos)
                    output_lines.append(f"\tCaminho:  --> {path[0]}") # Deveria ser impossível com o filtro 'if node != start_node'
            else:
                output_lines.append(f"\tCaminho: Não encontrado")
        # Sem linha em branco após cada par para corresponder exatamente à saída esperada.
        # A linha em branco é adicionada pelo loop principal para separar blocos de "Nó X para todos".
    return "\n".join(output_lines)


if __name__ == "__main__":
    # 1. Parsing da entrada para construir o grafo, agora do stdin
    graph_from_user = parse_input_from_stdin()

    # Verifica se o grafo foi construído
    if not graph_from_user:
        # print("Nenhum dado de grafo foi inserido ou o formato está incorreto. Encerrando.")
        sys.exit(1) # Sai com código de erro

    # 2. Encontrar todos os nós únicos no grafo para iterar
    all_nodes_in_graph = sorted(list(graph_from_user.keys())) # Garante a ordem dos blocos de saída

    # 3. Calcular e exibir os caminhos para cada nó inicial
    final_output = []
    for start_node_iter in all_nodes_in_graph:
        distances, predecessors = dijkstra(graph_from_user, start_node_iter)
        
        # Gera o bloco de saída para o nó inicial atual
        block_output = format_output(start_node_iter, distances, predecessors, all_nodes_in_graph)
        if block_output: # Adiciona apenas se houver caminhos para exibir
            final_output.append(block_output)
            final_output.append("-" * 45) # Separador entre os nós iniciais

    # Remove o último separador se houver (para não ter um "---" extra no final)
    if final_output and final_output[-1] == "-" * 45:
        final_output.pop()

    print("\n".join(final_output))